// GENERATED CODE - DO NOT EDIT
// 由 dynamic_flutter_generator 从 lib/components/image_icon_detail.dart 自动生成
// 重新生成：dart run build_runner build

import { AssetImage, Center, Colors, Column, CrossAxisAlignment, EdgeInsets, FontWeight, Icon, Icons, ImageIcon, Padding, Row, SizedBox, StatelessWidget, Text, TextAlign, TextStyle } from '../flutter.js';

// 组件 ImageIconDetail
export class ImageIconDetail extends StatelessWidget {
  constructor(args) {
    super(args);
  }
  _cell(label, icon) {
    return new SizedBox({
      "width": 96,
      "child": new Column({
        "children": [
          new SizedBox({
            "height": 64,
            "child": new Center({
              "child": icon
            })
          }),
          (this.__k0 || (this.__k0 = new SizedBox({
            "height": 6
          }))),
          new Text({
            "textAlign": TextAlign.center,
            "style": (this.__k1 || (this.__k1 = new TextStyle({
              "color": Colors.black54,
              "fontSize": 11
            }))),
            "data": label
          })
        ]
      })
    });
  }
  _section(title, content) {
    return new Padding({
      "padding": (this.__k2 || (this.__k2 = EdgeInsets.only({
        "bottom": 12
      }))),
      "child": new Column({
        "crossAxisAlignment": CrossAxisAlignment.start,
        "children": [
          new Text({
            "style": (this.__k3 || (this.__k3 = new TextStyle({
              "color": Colors.black54,
              "fontSize": 12
            }))),
            "data": title
          }),
          (this.__k0 || (this.__k0 = new SizedBox({
            "height": 6
          }))),
          content
        ]
      })
    });
  }
  build(context) {
    return new Column({
      "crossAxisAlignment": CrossAxisAlignment.start,
      "children": [
        (this.__k4 || (this.__k4 = new Text({
          "data": "ImageIcon",
          "style": new TextStyle({
            "fontWeight": FontWeight.bold
          })
        }))),
        (this.__k5 || (this.__k5 = new SizedBox({
          "height": 4
        }))),
        (this.__k6 || (this.__k6 = new Text({
          "data": "图片作为图标：尺寸 / 颜色（srcIn 染色）/ 与 Icon 对照",
          "style": new TextStyle({
            "fontSize": 12,
            "color": Colors.black54
          })
        }))),
        (this.__k7 || (this.__k7 = new SizedBox({
          "height": 12
        }))),
        this._section("① size：24 / 36 / 48（颜色继承 IconTheme）", new Row({
          "crossAxisAlignment": CrossAxisAlignment.end,
          "children": [
            this._cell("size 24", (this.__k8 || (this.__k8 = new ImageIcon({
              "image": new AssetImage({
                "assetName": "assets/images/photo-1494790108377-be9c29b29330.jpg"
              }),
              "size": 24
            })))),
            this._cell("size 36", (this.__k9 || (this.__k9 = new ImageIcon({
              "image": new AssetImage({
                "assetName": "assets/images/photo-1494790108377-be9c29b29330.jpg"
              }),
              "size": 36
            })))),
            this._cell("size 48", (this.__k10 || (this.__k10 = new ImageIcon({
              "image": new AssetImage({
                "assetName": "assets/images/photo-1494790108377-be9c29b29330.jpg"
              }),
              "size": 48
            }))))
          ]
        })),
        this._section("② color：srcIn 染色（同一张图 → 同色剪影）", new Row({
          "children": [
            this._cell("teal", (this.__k11 || (this.__k11 = new ImageIcon({
              "color": Colors.teal,
              "image": new AssetImage({
                "assetName": "assets/images/photo-1494790108377-be9c29b29330.jpg"
              }),
              "size": 40
            })))),
            this._cell("deepOrange", (this.__k12 || (this.__k12 = new ImageIcon({
              "color": Colors.deepOrange,
              "image": new AssetImage({
                "assetName": "assets/images/photo-1494790108377-be9c29b29330.jpg"
              }),
              "size": 40
            })))),
            this._cell("indigo", (this.__k13 || (this.__k13 = new ImageIcon({
              "color": Colors.indigo,
              "image": new AssetImage({
                "assetName": "assets/images/photo-1494790108377-be9c29b29330.jpg"
              }),
              "size": 40
            }))))
          ]
        })),
        this._section("③ 与 Icon 并排（同尺寸同色，字形 vs 图片）", new Row({
          "children": [
            this._cell("ImageIcon", (this.__k14 || (this.__k14 = new ImageIcon({
              "color": Colors.deepPurple,
              "image": new AssetImage({
                "assetName": "assets/images/photo-1448375240586-882707db888b.jpg"
              }),
              "size": 40
            })))),
            this._cell("Icon", (this.__k15 || (this.__k15 = new Icon({
              "color": Colors.deepPurple,
              "icon": Icons.park,
              "size": 40
            }))))
          ]
        })),
        this._section("④ 实际用法：徽标 + 文案（semanticLabel 只影响无障碍朗读）", new Row({
          "children": [
            (this.__k16 || (this.__k16 = new ImageIcon({
              "color": Colors.teal,
              "image": new AssetImage({
                "assetName": "assets/images/photo-1501785888041-af3ef285b470.jpg"
              }),
              "semanticLabel": "风景徽标",
              "size": 28
            }))),
            (this.__k17 || (this.__k17 = new SizedBox({
              "width": 8
            }))),
            (this.__k18 || (this.__k18 = new Text({
              "data": "图片图标可直接用在 Row / ListTile.leading 里"
            })))
          ]
        }))
      ]
    });
  }
}

